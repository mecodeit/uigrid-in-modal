var app = angular.module('app', ['ngTouch', 'ui.grid']);

app.controller('MainCtrl', ['$rootScope', '$scope', '$http', '$compile', '$interval', 
function ($rootScope, $scope, $http, $compile, $interval) {
  
  $scope.hideGrid = true;

  $rootScope.gridOptions = {
    onRegisterApi: function (gridApi) {
      $scope.gridApi = gridApi;

      // call resize every 500 ms for 5 s after modal finishes opening - usually only necessary on a bootstrap modal
      $interval( function() {
        $scope.gridApi.core.handleWindowResize();
      }, 500, 10);
      }
  };

  $http.get('https://cdn.rawgit.com/angular-ui/ui-grid.info/gh-pages/data/100.json')
    .success(function(data) {
      $rootScope.gridOptions.data = data;
    });

  
}]);